package com.netshield

class Netshield {
    companion object {
        init {
            System.loadLibrary("netshield")
        }

        /**
        * 启动防护服务
        * @param pid 客服提供的pid
        * @param key 客服提供的key
        * @return 0-SDK启动成功 -1-SDK启动失败
        */
        @JvmStatic
        external fun startService(pid: String, key: String): Int

        /**
        * 根据规则名获取本地监听端口，需要在startNetshieldService执行后调用
        * @param rule 规则名
        * @return 规则名对应的本地监听端口
        */
        @JvmStatic
        external fun getLocalhostPort(rule: String): Int

        /**
        * 获取客户端真实IP，需要在SDK启动成功后调用
        * @return 客户端真实IP，如果SDK未启动则返回空字符串
        */
        @JvmStatic
        external fun getClientIP(): String

        /**
        * 获取SDK启动失败的错误信息
        * @return SDK启动失败的错误信息
        */
        @JvmStatic
        external fun getErrMessage(): String

        /**
        * 停止防护服务，释放资源
        */
        @JvmStatic
        external fun stopService()
    }
}