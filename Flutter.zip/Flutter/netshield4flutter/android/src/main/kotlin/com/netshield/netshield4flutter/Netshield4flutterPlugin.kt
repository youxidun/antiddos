package com.netshield.netshield4flutter

import androidx.annotation.NonNull

import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result

import com.netshield.Netshield

/** Netshield4flutterPlugin */
class Netshield4flutterPlugin: FlutterPlugin, MethodCallHandler {
  /// The MethodChannel that will the communication between Flutter and native Android
  ///
  /// This local reference serves to register the plugin with the Flutter Engine and unregister it
  /// when the Flutter Engine is detached from the Activity
  private lateinit var channel : MethodChannel

  override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
    channel = MethodChannel(flutterPluginBinding.binaryMessenger, "netshield4flutter")
    channel.setMethodCallHandler(this)
  }

  override fun onMethodCall(call: MethodCall, result: Result) {
    if (call.method == "getPlatformVersion") {
      result.success("Android ${android.os.Build.VERSION.RELEASE}")
    } else if (call.method == "startService") {
      val pid = call.argument<String>("pid") ?: ""
      val key = call.argument<String>("key") ?: ""
      val startResult = Netshield.startService(pid, key)
      if (0 == startResult) {
        val clientIP = Netshield.getClientIP()
        result.success(
          mapOf(
            "startResult" to 0,
            "clientIP" to clientIP,
            "errMessage" to ""
          )
        )
      } else {
        val errMessage = Netshield.getErrMessage()
        result.success(
          mapOf(
            "startResult" to -1,
            "clientIP" to "",
            "errMessage" to errMessage
          )
        )
      }
    } else if (call.method == "getLocalhostPort") {
      val rule = call.argument<String>("rule") ?: ""
      val localhostPort = Netshield.getLocalhostPort(rule)
      result.success(localhostPort)
    } else if (call.method == "stopService") {
      Netshield.stopService()
      result.success(null)
    } else {
      result.notImplemented()
    }
  }

  override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
    channel.setMethodCallHandler(null)
  }
}
