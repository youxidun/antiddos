# 使用说明
## 添加依赖
通过本地路径的方式引入plugin
```
dependencies:
  netshield4flutter:
    path: ../path/to/your/netshield4flutter
```
## 使用说明
测试代码参考example
```
import 'package:netshield4flutter/netshield4flutter.dart';

final _netshield4flutterPlugin = Netshield4flutter();
try {
    final startResult = await _netshield4flutterPlugin.startService('123', '9fc97717f0d1fedde854fb8b9e1db7fb');
    if (startResult.isSuccess) {
    setState(() => sdkRunning = true);
    _addLog("SDK 已启动");
    _addLog('Client IP: ${startResult.clientIP}');
    int localhostPort = await _netshield4flutterPlugin.getLocalhostPort("240.0.0.2;80");
    urlController.text="http://127.0.0.1:$localhostPort";
    } else {
    _addLog("SDK 启动失败: ${startResult.errorMessage}");
    }
} on PlatformException {
    _addLog("SDK 启动失败");
}

try {
    await _netshield4flutterPlugin.stopService();
    setState(() => sdkRunning = false);
    _addLog("SDK 已停止");
} on PlatformException {
    _addLog("SDK 停止失败");
}
```