import 'package:flutter_test/flutter_test.dart';
import 'package:netshield4flutter/netshield4flutter.dart';
import 'package:netshield4flutter/netshield4flutter_platform_interface.dart';
import 'package:netshield4flutter/netshield4flutter_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockNetshield4flutterPlatform
    with MockPlatformInterfaceMixin
    implements Netshield4flutterPlatform {

  @override
  Future<String?> getPlatformVersion() => Future.value('42');
}

void main() {
  final Netshield4flutterPlatform initialPlatform = Netshield4flutterPlatform.instance;

  test('$MethodChannelNetshield4flutter is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelNetshield4flutter>());
  });

  test('getPlatformVersion', () async {
    Netshield4flutter netshield4flutterPlugin = Netshield4flutter();
    MockNetshield4flutterPlatform fakePlatform = MockNetshield4flutterPlatform();
    Netshield4flutterPlatform.instance = fakePlatform;

    expect(await netshield4flutterPlugin.getPlatformVersion(), '42');
  });
}
