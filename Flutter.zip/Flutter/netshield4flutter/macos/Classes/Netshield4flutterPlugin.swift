import Cocoa
import FlutterMacOS

public class Netshield4flutterPlugin: NSObject, FlutterPlugin {
  private let netshieldBridge = NetshieldBridge()

  public static func register(with registrar: FlutterPluginRegistrar) {
    let channel = FlutterMethodChannel(name: "netshield4flutter", binaryMessenger: registrar.messenger)
    let instance = Netshield4flutterPlugin()
    registrar.addMethodCallDelegate(instance, channel: channel)
  }

  public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    switch call.method {
    case "getPlatformVersion":
      result("macOS " + ProcessInfo.processInfo.operatingSystemVersionString)
    case "startService":
      guard let args = call.arguments as? [String: Any],
            let pid = args["pid"] as? String,
            let key = args["key"] as? String else {
        result(FlutterError(
          code: "-1",
          message: "Invalid arguments", 
          details: nil
        ))
        return
      }
      netshieldBridge?.startService(pid: pid, key: key, completionHandler: { (startResult, errMessage, clientIP) in
        // 确保在主线程回调Flutter
        DispatchQueue.main.async {
          // 将结果封装成字典
          let resultMap: [String: Any?] = [
            "startResult": startResult,
            "errMessage": errMessage,
            "clientIP": clientIP
          ]
          // 将结果返回给Flutter
          result(resultMap)
        }
      })   
    case "getLocalhostPort":
      guard let args = call.arguments as? [String: Any],
            let rule = args["rule"] as? String else {
        result(FlutterError(
          code: "-1",
          message: "Missing rule",
          details: nil
        ))
        return
      }
      let localhostPort = netshieldBridge?.getLocalhostPort(rule: rule)
      result(localhostPort)  
    case "stopService":
      netshieldBridge?.stopService()
      result(nil) 
    default:
      result(FlutterMethodNotImplemented)
    }
  }
}
