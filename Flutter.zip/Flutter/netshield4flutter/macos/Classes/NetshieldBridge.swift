import Cocoa

typealias StartNetshieldServiceCallback = @convention(c) (Int32, UnsafePointer<CChar>?, UnsafePointer<CChar>?) -> Void
typealias StartNetshieldServiceFunc = @convention(c) (UnsafePointer<CChar>?, UnsafePointer<CChar>?, @escaping StartNetshieldServiceCallback) -> Void
typealias GetLocalhostPortFunc = @convention(c) (UnsafePointer<CChar>?) -> Int32
typealias StopNetshieldServiceFunc = @convention(c) () -> Void

public class NetshieldBridge {
    private var handle: UnsafeMutableRawPointer?

    static var pendingCallback: ((Int32, String?, String?) -> Void)?

    private var startNetshieldServiceFunc: StartNetshieldServiceFunc?
    private var getPortFunc: GetLocalhostPortFunc?
    private var stopNetshieldFunc: StopNetshieldServiceFunc?

    init?() {
        handle = dlopen("@rpath/libnetshield.dylib", RTLD_NOW)
        guard let handle = handle else {
            print("❌ dlopen failed: \(String(cString: dlerror()))")
            return nil
        }

        guard
            let start = dlsym(handle, "startNetshieldService"),
            let getPort = dlsym(handle, "getLocalhostPort"),
            let stop = dlsym(handle, "stopNetshieldService")
        else {
            print("❌ dlsym failed: \(String(cString: dlerror()))")
            return nil
        }

        startNetshieldServiceFunc = unsafeBitCast(start, to: StartNetshieldServiceFunc.self)
        getPortFunc = unsafeBitCast(getPort, to: GetLocalhostPortFunc.self)
        stopNetshieldFunc = unsafeBitCast(stop, to: StopNetshieldServiceFunc.self)
    }

    deinit {
        if let handle = handle {
            dlclose(handle)
        }
    }

    func startService(pid: String, key: String, completionHandler: @escaping (Int32, String?, String?) -> Void) {
        guard let funcPtr = startNetshieldServiceFunc else {
            print("⚠️ StartService function not loaded")
            return
        }
        let cCompletionHandler: StartNetshieldServiceCallback = { startResult, cErrMessage, cClientIP in
          let errMessage = cErrMessage != nil ? String(cString: cErrMessage!) : nil
          let clientIP = cClientIP != nil ? String(cString: cClientIP!) : nil
          NetshieldBridge.pendingCallback?(startResult, errMessage, clientIP)
          NetshieldBridge.pendingCallback = nil
        }
        NetshieldBridge.pendingCallback = { startResult, errMessage, clientIP in
          completionHandler(startResult, errMessage ?? "", clientIP ?? "")
        }
        pid.withCString { cPid in
            key.withCString { cKey in
                funcPtr(cPid, cKey, cCompletionHandler)
            }
        }
    }

    func getLocalhostPort(rule: String) -> Int32 {
        guard let funcPtr = getPortFunc else {
            print("⚠️ GetLocalhostPort function not loaded")
            return -1
        }

        return rule.withCString { cRule in
            funcPtr(cRule)
        }
    }

    func stopService() {
        guard let funcPtr = stopNetshieldFunc else {
            print("⚠️ StopNetshieldService function not loaded")
            return
        }

        funcPtr()
    }
}
