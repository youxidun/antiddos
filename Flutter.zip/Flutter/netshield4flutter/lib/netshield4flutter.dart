
import 'netshield4flutter_platform_interface.dart';

class Netshield4flutter {
  Future<String?> getPlatformVersion() {
    return Netshield4flutterPlatform.instance.getPlatformVersion();
  }

  Future<NetshieldStartResult> startService(String pid, String key) {
    return Netshield4flutterPlatform.instance.startService(pid, key);
  }
  
  Future<int> getLocalhostPort(String rule) {
    return Netshield4flutterPlatform.instance.getLocalhostPort(rule);
  }
  
  Future<void> stopService() {
    return Netshield4flutterPlatform.instance.stopService();
  }
}
