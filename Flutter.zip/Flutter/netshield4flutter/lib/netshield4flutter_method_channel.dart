import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'netshield4flutter_platform_interface.dart';

/// An implementation of [Netshield4flutterPlatform] that uses method channels.
class MethodChannelNetshield4flutter extends Netshield4flutterPlatform {
  /// The method channel used to interact with the native platform.
  @visibleForTesting
  final methodChannel = const MethodChannel('netshield4flutter');

  @override
  Future<String?> getPlatformVersion() async {
    final version = await methodChannel.invokeMethod<String>('getPlatformVersion');
    return version;
  }

  @override
  Future<NetshieldStartResult> startService(String pid, String key) async {
    final result = await methodChannel.invokeMethod<Map<dynamic, dynamic>>('startService', {
      'pid': pid,
      'key': key,
    });
    return NetshieldStartResult(
      resultCode: result?['startResult'] as int? ?? -1,
      clientIP: result?['clientIP'] as String? ?? '',
      errMessage: result?['errMessage'] as String? ?? 'fatal error',
    );
  }

  @override
  Future<int> getLocalhostPort(String rule) async {
    final port = await methodChannel.invokeMethod<int>('getLocalhostPort', {
      'rule': rule
    });
    return port ?? -1;
  }
  
  @override
  Future<void> stopService() async {
    await methodChannel.invokeMethod('stopService');
  }
}
