import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'netshield4flutter_method_channel.dart';

class NetshieldStartResult {
  final int resultCode;
  final String clientIP;
  final String errMessage;
  
  NetshieldStartResult({
    required this.resultCode,
    required this.clientIP,
    required this.errMessage,
  });
  
  bool get isSuccess => resultCode == 0;
}

abstract class Netshield4flutterPlatform extends PlatformInterface {
  /// Constructs a Netshield4flutterPlatform.
  Netshield4flutterPlatform() : super(token: _token);

  static final Object _token = Object();

  static Netshield4flutterPlatform _instance = MethodChannelNetshield4flutter();

  /// The default instance of [Netshield4flutterPlatform] to use.
  ///
  /// Defaults to [MethodChannelNetshield4flutter].
  static Netshield4flutterPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [Netshield4flutterPlatform] when
  /// they register themselves.
  static set instance(Netshield4flutterPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }

  Future<NetshieldStartResult> startService(String pid, String key) {
    throw UnimplementedError('startService(String, String) has not been implemented.');
  }
  
  Future<int> getLocalhostPort(String rule) {
    throw UnimplementedError('getLocalhostPort(String) has not been implemented.');
  }
  
  Future<void> stopService() {
    throw UnimplementedError('stopService() has not been implemented.');
  }
}
