import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:netshield4flutter/netshield4flutter.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Netshield测试Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
      ),
      home: const SdkControlPage(),
    );
  }
}

class SdkControlPage extends StatefulWidget {
  const SdkControlPage({Key? key}) : super(key: key);

  @override
  SdkControlPageState createState() => SdkControlPageState();
}

class SdkControlPageState extends State<SdkControlPage> {
  List<String> logs = [];
  bool sdkRunning = false;
  final urlController = TextEditingController(text: "");
  late ScrollController _scrollController; // 新增滚动控制器

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController(); // 初始化滚动控制器
  }

  @override
  void dispose() {
    urlController.dispose();
    _scrollController.dispose(); // 释放滚动控制器
    super.dispose();
  }

  void _addLog(String message) {
    setState(() {
      // 现在将日志添加到列表末尾
      logs.add("[${DateTime.now().toString().substring(11, 19)}] $message");
      if (logs.length > 100) {
        logs.removeAt(0); // 移除最旧的一条日志
      }
      
      // 滚动到日志底部（新日志位置）
      WidgetsBinding.instance!.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    });
  }

  final _netshield4flutterPlugin = Netshield4flutter();

  // 启动SDK
  Future<void> _startSdk() async {
    try {
      final startResult = await _netshield4flutterPlugin.startService('123', '9fc97717f0d1fedde854fb8b9e1db7fb');
      if (startResult.isSuccess) {
        setState(() => sdkRunning = true);
        _addLog("SDK 已启动");
        _addLog('Client IP: ${startResult.clientIP}');
      } else {
        _addLog("SDK 启动失败: ${startResult.errMessage}");
        if (!mounted) return;
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text("提示"),
              content: Text(startResult.errMessage),
              actions: <Widget>[
                TextButton(
                  child: const Text("确认"),
                  onPressed: () {
                    Navigator.of(context).pop(); // 关闭对话框
                  },
                ),
              ],
            );
          },
        );
      }
    } on PlatformException {
      _addLog("SDK 启动失败");
    }
  }

  // 停止SDK
  Future<void> _stopSdk() async {
    try {
      await _netshield4flutterPlugin.stopService();
      setState(() => sdkRunning = false);
      _addLog("SDK 已停止");
    } on PlatformException {
      _addLog("SDK 停止失败");
    }
  }

  // 访问HTTP网页
  Future<void> _visitWebpage() async {
    int localhostPort = await _netshield4flutterPlugin.getLocalhostPort("240.0.0.2;80");
    urlController.text="http://127.0.0.1:$localhostPort";
    String url = urlController.text;
    
    if (!url.startsWith("http://")) {
      _addLog("错误：URL必须以http://开头");
      return;
    }
    
    _addLog("正在访问: $url");
    
    try {
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        // 计算字节数
        int byteCount = response.bodyBytes.length;
        _addLog("请求成功: HTTP ${response.statusCode}");
        _addLog("响应大小: $byteCount 字节");
        
        // 显示响应的前200个字符
        String preview = response.body;
        if (preview.length > 200) {
          preview = '${preview.substring(0, 200)}...';
        }
        _addLog("响应预览: $preview");
      } else {
        _addLog("请求失败: HTTP ${response.statusCode}");
      }
    } catch (e) {
      _addLog("请求异常: ${e.toString()}");
      if (e is SocketException) {
        _addLog("网络连接失败，请检查URL是否正确");
      } else if (e is http.ClientException) {
        _addLog("客户端错误: ${e.message}");
      }
    }
  }

  // 复制日志到剪贴板
  void _copyLogsToClipboard() {
    Clipboard.setData(ClipboardData(text: logs.join("\n")));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("日志已复制到剪贴板")),
    );
  }

  // 清除日志
  void _clearLogs() {
    setState(() {
      logs.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Netshield测试Demo'),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy),
            onPressed: _copyLogsToClipboard,
            tooltip: "复制日志",
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _clearLogs,
            tooltip: "清除日志",
          ),
        ],
      ),
      body: Column(
        children: [
          // URL输入区域
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: urlController,
                    decoration: InputDecoration(
                      labelText: '输入HTTP URL',
                      hintText: 'http://example.com',
                      prefixIcon: const Icon(Icons.link),
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => urlController.clear(),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // 按钮区域 - 保持在一行
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // 启动按钮
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ElevatedButton(
                      onPressed: sdkRunning ? null : _startSdk,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        minimumSize: const Size.fromHeight(48),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.play_arrow),
                          SizedBox(width: 8),
                          Text('启动 SDK'),
                        ],
                      ),
                    ),
                  ),
                ),
                
                // 停止按钮
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ElevatedButton(
                      onPressed: !sdkRunning ? null : _stopSdk,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        minimumSize: const Size.fromHeight(48),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.stop),
                          SizedBox(width: 8),
                          Text('停止 SDK'),
                        ],
                      ),
                    ),
                  ),
                ),
                
                // 访问按钮
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ElevatedButton(
                      onPressed: sdkRunning ? _visitWebpage : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        minimumSize: const Size.fromHeight(48),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.public),
                          SizedBox(width: 8),
                          Text('访问页面'),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // 日志显示区域（现在在按钮下方）
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.blueGrey.shade700),
                color: Colors.grey.shade900,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
              ),
              child: ListView.builder(
                controller: _scrollController, // 添加滚动控制器
                itemCount: logs.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(
                      logs[index], // 直接显示（不反转）
                      style: const TextStyle(
                        color: Colors.lightGreenAccent,
                        fontSize: 14,
                        fontFamily: 'monospace',
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}