package com.netshield.netshield4flutter_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
