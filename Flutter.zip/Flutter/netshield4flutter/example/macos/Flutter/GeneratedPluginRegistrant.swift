//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import netshield4flutter

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  Netshield4flutterPlugin.register(with: registry.registrar(forPlugin: "Netshield4flutterPlugin"))
}
