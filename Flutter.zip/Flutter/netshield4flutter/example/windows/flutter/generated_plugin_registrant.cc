//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <netshield4flutter/netshield4flutter_plugin_c_api.h>

void RegisterPlugins(flutter::PluginRegistry* registry) {
  Netshield4flutterPluginCApiRegisterWithRegistrar(
      registry->GetRegistrarForPlugin("Netshield4flutterPluginCApi"));
}
