#include "netshield4flutter_plugin.h"

// This must be included before many other Windows headers.
#include <windows.h>

// For getPlatformVersion; remove unless needed for your plugin implementation.
#include <VersionHelpers.h>

#include <flutter/method_channel.h>
#include <flutter/plugin_registrar_windows.h>
#include <flutter/standard_method_codec.h>

#include <memory>
#include <sstream>

namespace netshield4flutter {
// static
void Netshield4flutterPlugin::RegisterWithRegistrar(flutter::PluginRegistrarWindows *registrar) {
    auto channel = std::make_unique<flutter::MethodChannel<flutter::EncodableValue>>(registrar->messenger(), "netshield4flutter", &flutter::StandardMethodCodec::GetInstance());
    auto plugin  = std::make_unique<Netshield4flutterPlugin>();
    channel->SetMethodCallHandler([plugin_pointer = plugin.get()](const auto &call, auto result) { plugin_pointer->HandleMethodCall(call, std::move(result)); });
    registrar->AddPlugin(std::move(plugin));
}

Netshield4flutterPlugin::Netshield4flutterPlugin() {
    HMODULE netshieldDll        = LoadLibrary(L"netshield.dll");
    m_startNetshieldServiceFunc = reinterpret_cast<int(__cdecl *)(const char *, const char *)>(GetProcAddress(netshieldDll, "startNetshieldService"));
    m_getClientIPFunc           = reinterpret_cast<const char *(__cdecl *)()>(GetProcAddress(netshieldDll, "getClientIP"));
    m_getErrMessageFunc         = reinterpret_cast<const char *(__cdecl *)()>(GetProcAddress(netshieldDll, "getErrMessage"));
    m_stopNetshieldServiceFunc  = reinterpret_cast<void(__cdecl *)()>(GetProcAddress(netshieldDll, "stopNetshieldService"));
    m_getLocalhostPortFunc      = reinterpret_cast<int(__cdecl *)(const char *)>(GetProcAddress(netshieldDll, "getLocalhostPort"));
}

Netshield4flutterPlugin::~Netshield4flutterPlugin() {}

void Netshield4flutterPlugin::HandleMethodCall(const flutter::MethodCall<flutter::EncodableValue> &method_call, std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
    if (method_call.method_name().compare("getPlatformVersion") == 0) {
        std::ostringstream version_stream;
        version_stream << "Windows ";
        if (IsWindows10OrGreater()) {
            version_stream << "10+";
        } else if (IsWindows8OrGreater()) {
            version_stream << "8";
        } else if (IsWindows7OrGreater()) {
            version_stream << "7";
        }
        result->Success(flutter::EncodableValue(version_stream.str()));
    } else if (method_call.method_name().compare("startService") == 0) {
        const auto *args = std::get_if<flutter::EncodableMap>(method_call.arguments());
        std::string pid, key;
        if (args) {
            auto pid_it = args->find(flutter::EncodableValue("pid"));
            if (pid_it != args->end() && !pid_it->second.IsNull()) {
                pid = std::get<std::string>(pid_it->second);
            }
            auto key_it = args->find(flutter::EncodableValue("key"));
            if (key_it != args->end() && !key_it->second.IsNull()) {
                key = std::get<std::string>(key_it->second);
            }
        }
        flutter::EncodableMap response;
        int                   startResult                = m_startNetshieldServiceFunc(pid.c_str(), key.c_str());
        response[flutter::EncodableValue("startResult")] = flutter::EncodableValue(startResult);
        if (0 == startResult) {
            const char *clientIP                            = m_getClientIPFunc();
            response[flutter::EncodableValue("clientIP")]   = flutter::EncodableValue(std::string(clientIP));
            response[flutter::EncodableValue("errMessage")] = flutter::EncodableValue("");
        } else {
            const char *errMessage                          = m_getErrMessageFunc();
            response[flutter::EncodableValue("clientIP")]   = flutter::EncodableValue("");
            response[flutter::EncodableValue("errMessage")] = flutter::EncodableValue(std::string(errMessage));
        }
        result->Success(flutter::EncodableValue(response));
    } else if (method_call.method_name().compare("getLocalhostPort") == 0) {
        std::string rule;
        const auto *args = std::get_if<flutter::EncodableMap>(method_call.arguments());
        if (args) {
            auto rule_it = args->find(flutter::EncodableValue("rule"));
            if (rule_it != args->end() && !rule_it->second.IsNull()) {
                rule = std::get<std::string>(rule_it->second);
            }
        }
        int port = m_getLocalhostPortFunc(rule.c_str());
        result->Success(flutter::EncodableValue(port));
    } else if (method_call.method_name().compare("stopService") == 0) {
        m_stopNetshieldServiceFunc();
        result->Success();
    } else {
        result->NotImplemented();
    }
}

} // namespace netshield4flutter
