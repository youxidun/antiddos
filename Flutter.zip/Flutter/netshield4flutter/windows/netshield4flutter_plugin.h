#ifndef FLUTTER_PLUGIN_NETSHIELD4FLUTTER_PLUGIN_H_
#define FLUTTER_PLUGIN_NETSHIELD4FLUTTER_PLUGIN_H_

#include <flutter/method_channel.h>
#include <flutter/plugin_registrar_windows.h>

#include <memory>

namespace netshield4flutter {

class Netshield4flutterPlugin : public flutter::Plugin {
public:
    static void RegisterWithRegistrar(flutter::PluginRegistrarWindows *registrar);

    Netshield4flutterPlugin();

    virtual ~Netshield4flutterPlugin();

    // Disallow copy and assign.
    Netshield4flutterPlugin(const Netshield4flutterPlugin &)            = delete;
    Netshield4flutterPlugin &operator=(const Netshield4flutterPlugin &) = delete;

    // Called when a method is called on this plugin's channel from Dart.
    void HandleMethodCall(const flutter::MethodCall<flutter::EncodableValue> &method_call, std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result);

private:
    typedef int (*StartNetshieldServiceFunc)(const char *, const char *);
    typedef const char *(*GetClientIPFunc)();
    typedef const char *(*GetErrMessageFunc)();
    typedef void (*StopNetshieldServiceFunc)();
    typedef int (*GetLocalhostPortFunc)(const char *);

    StartNetshieldServiceFunc m_startNetshieldServiceFunc;
    GetClientIPFunc           m_getClientIPFunc;
    GetErrMessageFunc         m_getErrMessageFunc;
    StopNetshieldServiceFunc  m_stopNetshieldServiceFunc;
    GetLocalhostPortFunc      m_getLocalhostPortFunc;
};

} // namespace netshield4flutter

#endif // FLUTTER_PLUGIN_NETSHIELD4FLUTTER_PLUGIN_H_
