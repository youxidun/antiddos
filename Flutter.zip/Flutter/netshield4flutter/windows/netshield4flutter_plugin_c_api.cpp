#include "include/netshield4flutter/netshield4flutter_plugin_c_api.h"

#include <flutter/plugin_registrar_windows.h>

#include "netshield4flutter_plugin.h"

void Netshield4flutterPluginCApiRegisterWithRegistrar(FlutterDesktopPluginRegistrarRef registrar) {
    netshield4flutter::Netshield4flutterPlugin::RegisterWithRegistrar(flutter::PluginRegistrarManager::GetInstance()->GetRegistrar<flutter::PluginRegistrarWindows>(registrar));
}
